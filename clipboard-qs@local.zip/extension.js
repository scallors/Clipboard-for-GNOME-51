// Clipboard Quick Settings — GNOME Shell 51
// Clipboard history (text and images/screenshots) icon in the top-right tray.
//  - "Show inside system tray" ON  : the icon sits inside the system menu group
//                                    (Wi-Fi / volume / battery), no gap.
//  - "Show inside system tray" OFF : the icon is a standalone button next to it.

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Meta from 'gi://Meta';
import Pango from 'gi://Pango';
import St from 'gi://St';

import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as PopupMenu from 'resource:///org/gnome/shell/ui/popupMenu.js';
import {SystemIndicator} from 'resource:///org/gnome/shell/ui/quickSettings.js';

const MAX_ITEMS = 20;          // entries kept in history
const MAX_LENGTH = 100000;     // ignore absurdly large copies
const PASSWORD_HINT = 'x-kde-passwordManagerHint'; // set by KeePassXC, Bitwarden, etc.
const MAX_IMAGES = 8;                      // screenshots/images kept in history
const MAX_IMAGE_BYTES = 25 * 1024 * 1024;  // ignore images bigger than this
const THUMB_MAX_W = 200;                   // thumbnail bounds in the menu (px)
const THUMB_MAX_H = 112;

// Read width/height from a PNG header (screenshots are PNG). null if not a PNG.
function pngSize(data) {
    if (data.length < 24 || data[0] !== 0x89 || data[1] !== 0x50 ||
        data[2] !== 0x4e || data[3] !== 0x47)
        return null;
    const u32 = o => ((data[o] << 24) | (data[o + 1] << 16) | (data[o + 2] << 8) | data[o + 3]) >>> 0;
    return [u32(16), u32(20)];
}

// --- tiny config file (~/.config/clipboard-qs/config.json) -----------------
const CONFIG_DIR = GLib.build_filenamev([GLib.get_user_config_dir(), 'clipboard-qs']);
const CONFIG_FILE = GLib.build_filenamev([CONFIG_DIR, 'config.json']);

function loadConfig() {
    try {
        const [ok, bytes] = GLib.file_get_contents(CONFIG_FILE);
        if (ok)
            return JSON.parse(new TextDecoder().decode(bytes));
    } catch (e) {
        // no config yet
    }
    return {};
}

function saveConfig(config) {
    try {
        GLib.mkdir_with_parents(CONFIG_DIR, 0o755);
        GLib.file_set_contents(CONFIG_FILE, JSON.stringify(config));
    } catch (e) {
        console.error(`clipboard-qs: could not save config: ${e}`);
    }
}

// --- the clipboard button + popup menu --------------------------------------
const ClipboardButton = GObject.registerClass(
class ClipboardButton extends PanelMenu.Button {
    constructor(embedded, onEmbeddedToggled) {
        super(0.5, 'Clipboard History', false);

        this._destroyed = false;
        this._recording = true;
        this._history = [];
        this._clipboard = St.Clipboard.get_default();

        // Thumbnails of copied images live in $XDG_RUNTIME_DIR (RAM, wiped on logout)
        this._cacheDir = GLib.build_filenamev([GLib.get_user_runtime_dir(), 'clipboard-qs']);
        this._wipeCacheDir(false);

        this._icon = new St.Icon({
            icon_name: 'edit-paste-symbolic',
            style_class: 'system-status-icon',
        });
        this.add_child(this._icon);

        // Menu: switches, scrollable list, clear button
        this._recordSwitch = new PopupMenu.PopupSwitchMenuItem('Record clipboard', true);
        this._recordSwitch.connect('toggled', (_item, state) => {
            this._recording = state;
            this._icon.opacity = state ? 255 : 120;
            if (state)
                this._onClipboardChanged();
        });
        this.menu.addMenuItem(this._recordSwitch);

        this._embedSwitch = new PopupMenu.PopupSwitchMenuItem('Show inside system tray', embedded);
        this._embedSwitch.connect('toggled', (_item, state) => onEmbeddedToggled(state));
        this.menu.addMenuItem(this._embedSwitch);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());

        this._list = new St.BoxLayout({
            orientation: Clutter.Orientation.VERTICAL,
            x_expand: true,
        });
        const scroll = new St.ScrollView({
            style_class: 'clipboard-qs-scroll',
            overlay_scrollbars: true,
            hscrollbar_policy: St.PolicyType.NEVER,
            vscrollbar_policy: St.PolicyType.AUTOMATIC,
        });
        scroll.add_child(this._list);

        const section = new PopupMenu.PopupMenuSection();
        section.box.add_child(scroll);
        this.menu.addMenuItem(section);

        this.menu.addMenuItem(new PopupMenu.PopupSeparatorMenuItem());
        this._clearItem = this.menu.addAction('Clear history', () => this._clear());

        // Watch the clipboard
        this._selection = global.display.get_selection();
        this._selectionId = this._selection.connect('owner-changed', (_sel, type) => {
            if (type === Meta.SelectionType.SELECTION_CLIPBOARD)
                this._onClipboardChanged();
        });

        this._rebuild();
        this._onClipboardChanged(); // grab whatever is already on the clipboard
    }

    // In "inside system tray" mode the button itself is hidden and zero-width;
    // it only exists so the popup menu has something to anchor to.
    setCollapsed(collapsed) {
        this._icon.visible = !collapsed;
        this.reactive = !collapsed;
        this.can_focus = !collapsed;
        this.set_width(collapsed ? 0 : -1);
        if (collapsed)
            this.add_style_class_name('clipboard-qs-collapsed');
        else
            this.remove_style_class_name('clipboard-qs-collapsed');
    }

    cleanup() {
        this._destroyed = true;
        if (this._selectionId) {
            this._selection.disconnect(this._selectionId);
            this._selectionId = 0;
        }
        this._history = [];
        this._wipeCacheDir(true);
    }

    // Delete leftover thumbnail files (and optionally the directory itself)
    _wipeCacheDir(removeDir) {
        try {
            const dir = GLib.Dir.open(this._cacheDir, 0);
            let name;
            while ((name = dir.read_name()) !== null)
                GLib.unlink(GLib.build_filenamev([this._cacheDir, name]));
            dir.close();
            if (removeDir)
                GLib.rmdir(this._cacheDir);
        } catch (e) {
            // directory does not exist yet
        }
    }

    _onClipboardChanged() {
        if (this._destroyed || !this._recording)
            return;

        // Skip anything a password manager flagged as sensitive
        let mimes = [];
        try {
            mimes = this._clipboard.get_mimetypes(St.ClipboardType.CLIPBOARD) ?? [];
        } catch (e) {
            // mimetype lookup is best-effort
        }
        if (mimes.includes(PASSWORD_HINT))
            return;

        // Text wins if both are offered (e.g. copying spreadsheet cells);
        // pure image content (screenshots, "copy image") is stored as an image.
        const hasText = mimes.some(m =>
            m.startsWith('text/plain') || ['UTF8_STRING', 'STRING', 'TEXT'].includes(m));
        const imageMime = mimes.includes('image/png')
            ? 'image/png'
            : mimes.find(m => m.startsWith('image/'));

        if (!hasText && imageMime)
            this._readImage(imageMime);
        else
            this._readText();
    }

    _readText() {
        this._clipboard.get_text(St.ClipboardType.CLIPBOARD, (_clip, text) => {
            if (this._destroyed || !this._recording)
                return;
            if (!text || !text.trim() || text.length > MAX_LENGTH)
                return;
            this._pushEntry({key: `txt:${text}`, type: 'text', text});
        });
    }

    _readImage(mime) {
        this._clipboard.get_content(St.ClipboardType.CLIPBOARD, mime, (_clip, bytes) => {
            if (this._destroyed || !this._recording || !bytes)
                return;
            const size = bytes.get_size();
            if (size === 0 || size > MAX_IMAGE_BYTES)
                return;
            this._addImage(mime, bytes);
        });
    }

    _addImage(mime, bytes) {
        const sum = GLib.compute_checksum_for_bytes(GLib.ChecksumType.SHA256, bytes);
        const key = `img:${sum}`;

        // Same image copied again: just move it to the top
        const existing = this._history.find(e => e.key === key);
        if (existing) {
            this._pushEntry(existing);
            return;
        }

        const data = bytes.get_data();
        const dims = pngSize(data);
        const ext = mime === 'image/png'
            ? 'png'
            : ((mime.split('/')[1] ?? 'img').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'img');
        const path = GLib.build_filenamev([this._cacheDir, `${sum.slice(0, 16)}.${ext}`]);

        try {
            GLib.mkdir_with_parents(this._cacheDir, 0o700);
            GLib.file_set_contents(path, data);
        } catch (e) {
            console.error(`clipboard-qs: could not write thumbnail: ${e}`);
            return;
        }

        this._pushEntry({
            key, type: 'image', mime, bytes, path,
            width: dims ? dims[0] : 0,
            height: dims ? dims[1] : 0,
        });
    }

    _pushEntry(entry) {
        const idx = this._history.findIndex(e => e.key === entry.key);
        if (idx === 0)
            return;
        if (idx > 0)
            this._history.splice(idx, 1);
        this._history.unshift(entry);

        while (this._history.length > MAX_ITEMS)
            this._disposeEntry(this._history.pop());

        const images = this._history.filter(e => e.type === 'image');
        while (images.length > MAX_IMAGES) {
            const oldest = images.pop();
            this._history = this._history.filter(e => e !== oldest);
            this._disposeEntry(oldest);
        }

        this._rebuild();
    }

    _disposeEntry(entry) {
        if (entry.type === 'image')
            GLib.unlink(entry.path);
    }

    _remove(entry) {
        this._history = this._history.filter(e => e !== entry);
        this._disposeEntry(entry);
        this._rebuild();
    }

    _clear() {
        this._history = [];
        this._wipeCacheDir(false);
        this._rebuild();
    }

    _copy(entry) {
        // owner-changed fires afterwards and moves this entry to the top
        if (entry.type === 'image')
            this._clipboard.set_content(St.ClipboardType.CLIPBOARD, entry.mime, entry.bytes);
        else
            this._clipboard.set_text(St.ClipboardType.CLIPBOARD, entry.text);
        this.menu.close();
    }

    _rebuild() {
        this._list.destroy_all_children();

        if (this._history.length === 0) {
            this._list.add_child(new St.Label({
                text: 'Nothing copied yet',
                style_class: 'clipboard-qs-empty',
                x_align: Clutter.ActorAlign.CENTER,
                opacity: 160,
            }));
        } else {
            for (const entry of this._history)
                this._list.add_child(this._makeRow(entry));
        }

        this._clearItem.visible = this._history.length > 0;
    }

    _makeContent(entry) {
        if (entry.type === 'text') {
            const label = new St.Label({
                text: entry.text.replace(/\s+/g, ' ').trim().slice(0, 200),
                x_expand: true,
                y_align: Clutter.ActorAlign.CENTER,
            });
            label.clutter_text.ellipsize = Pango.EllipsizeMode.END;
            return [label];
        }

        // Image: thumbnail scaled to fit, plus its pixel size
        let tw = THUMB_MAX_W;
        let th = THUMB_MAX_H;
        if (entry.width && entry.height) {
            const scale = Math.min(THUMB_MAX_W / entry.width, THUMB_MAX_H / entry.height, 1);
            tw = Math.max(Math.round(entry.width * scale), 1);
            th = Math.max(Math.round(entry.height * scale), 1);
        }

        const thumb = new St.Bin({
            y_align: Clutter.ActorAlign.CENTER,
            style: `background-image: url("${entry.path}"); background-size: cover; ` +
                   `border-radius: 6px; width: ${tw}px; height: ${th}px;`,
        });
        const label = new St.Label({
            text: entry.width ? `Image · ${entry.width}×${entry.height}` : 'Image',
            x_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
            opacity: 170,
        });
        return [thumb, label];
    }

    _makeRow(entry) {
        const del = new St.Button({
            style_class: 'clipboard-qs-delete',
            can_focus: true,
            y_align: Clutter.ActorAlign.CENTER,
            child: new St.Icon({
                icon_name: 'edit-delete-symbolic',
                style_class: 'popup-menu-icon',
            }),
        });
        del.connect('clicked', () => this._remove(entry));

        const box = new St.BoxLayout({x_expand: true, style: 'spacing: 10px;'});
        for (const child of this._makeContent(entry))
            box.add_child(child);
        box.add_child(del);

        const row = new St.Button({
            style_class: 'popup-menu-item clipboard-qs-row',
            can_focus: true,
            track_hover: true,
            x_expand: true,
            x_align: Clutter.ActorAlign.FILL,
            child: box,
        });
        row.connect('clicked', () => this._copy(entry));
        return row;
    }
});

// --- extension entry point ---------------------------------------------------
export default class ClipboardQuickSettings extends Extension {
    enable() {
        this._config = loadConfig();
        this._embedded = this._config.embedded ?? true;

        this._button = new ClipboardButton(this._embedded, state => this._setEmbedded(state));

        // Standalone position: right before the system menu group.
        const box = Main.panel._rightBox;
        const position = box ? Math.max(box.get_n_children() - 1, 0) : 0;
        Main.panel.addToStatusArea(this.uuid, this._button, position, 'right');

        this._applyPlacement();
    }

    // Must stay synchronous — GNOME 51 throws if disable() is async.
    disable() {
        this._removeEmbeddedIcon();
        if (this._button) {
            this._button.cleanup();
            this._button.destroy();
            this._button = null;
        }
        this._config = null;
    }

    _setEmbedded(state) {
        this._embedded = state;
        this._config.embedded = state;
        saveConfig(this._config);
        this._applyPlacement();
    }

    _applyPlacement() {
        this._removeEmbeddedIcon();
        if (this._embedded)
            this._addEmbeddedIcon();
        else
            this._button.setCollapsed(false);
    }

    _addEmbeddedIcon() {
        const quickSettings = Main.panel.statusArea.quickSettings;
        if (!quickSettings) {
            this._button.setCollapsed(false);
            return;
        }

        // An icon inside the system menu group (the Wi-Fi/volume/battery pill)
        this._embedIcon = new SystemIndicator();
        const icon = this._embedIcon._addIndicator();
        icon.iconName = 'edit-paste-symbolic';
        quickSettings.addExternalIndicator(this._embedIcon);

        // Put it first in the group (leftmost)
        this._embedIcon.get_parent()?.set_child_at_index(this._embedIcon, 0);

        this._button.setCollapsed(true);

        // Clicking anywhere on that group opens Quick Settings. If the click
        // landed on our icon, open the clipboard menu instead.
        this._qsMenu = quickSettings.menu;
        this._qsOpenId = this._qsMenu.connect('open-state-changed', (_menu, open) => {
            if (!open || !this._pointerOnEmbeddedIcon())
                return;

            // Opening a second menu from inside this signal gets swallowed by
            // the click that is still being processed, so wait one tick, then
            // close Quick Settings and open the clipboard menu.
            if (this._idleId)
                GLib.source_remove(this._idleId);
            this._idleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                this._idleId = 0;
                if (!this._button)
                    return GLib.SOURCE_REMOVE;
                this._qsMenu?.close({animate: false});
                this._button.menu.open();
                return GLib.SOURCE_REMOVE;
            });
        });

        // Anchor the popup under our icon instead of the hidden button
        this._button.menu.sourceActor = this._embedIcon;
    }

    _removeEmbeddedIcon() {
        if (this._idleId) {
            GLib.source_remove(this._idleId);
            this._idleId = 0;
        }
        if (this._button)
            this._button.menu.sourceActor = this._button;
        if (this._qsMenu && this._qsOpenId) {
            this._qsMenu.disconnect(this._qsOpenId);
            this._qsOpenId = 0;
            this._qsMenu = null;
        }
        if (this._embedIcon) {
            this._embedIcon.destroy();
            this._embedIcon = null;
        }
    }

    _pointerOnEmbeddedIcon() {
        if (!this._embedIcon)
            return false;
        const [x, y] = global.get_pointer();
        const rect = this._embedIcon.get_transformed_extents();
        return x >= rect.origin.x && x <= rect.origin.x + rect.size.width &&
               y >= rect.origin.y && y <= rect.origin.y + rect.size.height;
    }
}
